module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "secret",
  DB: "learn"
};